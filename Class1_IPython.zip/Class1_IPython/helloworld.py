i = 0
while i < 3: 
    print("hello world!")
    i+=1